package com.author.app;

import java.util.Iterator;
import java.util.Set;

import org.hibernate.Session;

import com.author.data.Author;
import com.author.data.Person;
import com.author.data.Work;
import com.author.hbn.HibernateUtil;

public class PersonManage {
	public static void main(String[] args) {
	}


	private void updatePerson() {
	}

	private void deleteAuthor() {

	}

}
