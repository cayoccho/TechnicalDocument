package com.author.data.subclass;

import com.author.data.Work;

public class FactWork extends Work {


}
