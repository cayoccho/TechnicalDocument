package com.author.app;

import java.util.List;

import org.hibernate.Session;

import com.author.data.Work;
import com.author.data.subclass.FactWork;
import com.author.data.subclass.FictionWork;
import com.author.hbn.HibernateUtil;

public class TypesOfWork {
	public static void main(String[] args) {
		TypesOfWork tow = new TypesOfWork();
	}

	private void getWorks() {
	}

}
