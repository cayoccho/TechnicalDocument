package com.author.bidirection.data;

import java.util.Date;

public class PersonBD {
	private int personId;

	private String personName;

	private Date DOB;

	private int age;

	private String country;

	private String email;

	private AuthorBD auth;
	
	
	public AuthorBD getAuth() {
		return auth;
	}

	public void setAuth(AuthorBD auth) {
		this.auth = auth;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Date getDOB() {
		return DOB;
	}

	public void setDOB(Date dob) {
		DOB = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getPersonId() {
		return personId;
	}

	public void setPersonId(int personId) {
		this.personId = personId;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	
}
