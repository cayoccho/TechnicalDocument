package com.author.app;

import java.util.Iterator;
import java.util.Set;

import org.hibernate.Session;

import com.author.data.Author;
import com.author.data.Work;
import com.author.hbn.HibernateUtil;

public class AuthorManage {
	public static void main(String[] args) {
		AuthorManage am = new AuthorManage();
	}


	private void deleteLastWork() {
	}


	private void persistAuthor(Author auth) {
	}


	private Author loadAuthor() {
		return null;
	}


	private Author loadAndPersistAuthor() {
		return null;
	}

}
