package com.author.app;

import java.util.Set;

import org.hibernate.Session;

import com.author.bidirection.data.AuthorBD;
import com.author.bidirection.data.PersonBD;
import com.author.bidirection.data.WorkBD;
import com.author.hbn.HibernateUtil;


public class Bidirection {

	public static void main(String[] args) {
		Bidirection bd = new Bidirection();
		
	}

	private void listAuthorsAndworks() {
	}

	private void listAuthorsAndPersons() {
	}

}
