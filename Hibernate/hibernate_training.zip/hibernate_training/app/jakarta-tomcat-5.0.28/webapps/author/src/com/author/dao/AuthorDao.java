package com.author.dao;

import org.hibernate.Session;

import com.author.data.Author;
import com.trng.hbn.HibernateUtil;

public class AuthorDao {

	public void create(Author auth) {
	}

}
